"""
Test cases for the transformer ensemble model
"""

import pytest
from src.models.transformer_ensemble import TransformerEnsemble

def test_model_initialization():
    """Test model initialization"""
    model = TransformerEnsemble()
    assert model is not None
    assert hasattr(model, 'predict_single')
    assert hasattr(model, 'get_model_info')

def test_single_prediction():
    """Test single text prediction"""
    model = TransformerEnsemble()
    result = model.predict_single("Great product, highly recommend!")

    assert 'sentiment' in result
    assert 'topic' in result
    assert 'urgency' in result

    # Check sentiment prediction structure
    assert 'prediction' in result['sentiment']
    assert 'confidence' in result['sentiment']
    assert 'class_probabilities' in result['sentiment']

    # Check confidence is a valid probability
    assert 0.0 <= result['sentiment']['confidence'] <= 1.0

def test_model_info():
    """Test model information retrieval"""
    model = TransformerEnsemble()
    info = model.get_model_info()

    assert 'total_parameters' in info
    assert 'trainable_parameters' in info
    assert 'task_configs' in info
    assert 'label_mappings' in info

    assert info['total_parameters'] > 0
    assert info['trainable_parameters'] > 0

def test_sentiment_prediction_logic():
    """Test sentiment prediction logic"""
    model = TransformerEnsemble()

    # Test positive sentiment
    positive_result = model.predict_single("Amazing product, love it!")
    assert positive_result['sentiment']['prediction'] == 'positive'

    # Test negative sentiment  
    negative_result = model.predict_single("Terrible quality, awful experience!")
    assert negative_result['sentiment']['prediction'] == 'negative'
