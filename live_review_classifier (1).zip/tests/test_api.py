"""
Test cases for the API server
"""

import pytest
from fastapi.testclient import TestClient
from src.deployment.api_server import app

client = TestClient(app)

def test_root():
    """Test root endpoint"""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["service"] == "Live Review Classifier API"
    assert data["status"] == "operational"

def test_health_check():
    """Test health check endpoint"""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["model_loaded"] == True

def test_predict_single():
    """Test single review prediction"""
    response = client.post("/predict", json={
        "text": "Great product, fast shipping!"
    })
    assert response.status_code == 200
    data = response.json()
    assert "sentiment" in data
    assert "topic" in data
    assert "urgency" in data
    assert "processing_time_ms" in data

def test_predict_batch():
    """Test batch review prediction"""
    response = client.post("/predict/batch", json={
        "texts": [
            "Amazing quality!",
            "Terrible experience.",
            "Average product."
        ]
    })
    assert response.status_code == 200
    data = response.json()
    assert "predictions" in data
    assert len(data["predictions"]) == 3
    assert data["batch_size"] == 3

def test_invalid_text():
    """Test prediction with invalid text"""
    response = client.post("/predict", json={
        "text": ""
    })
    assert response.status_code == 422  # Validation error
