"""
Live Review Classifier - Configuration Utilities
===============================================
"""

import yaml
import os
from pathlib import Path
from typing import Dict, Any

def load_config(config_path: str) -> Dict[str, Any]:
    """Load YAML configuration file"""

    config_path = Path(config_path)

    if not config_path.exists():
        # Try relative to project root
        project_root = Path(__file__).parent.parent.parent
        config_path = project_root / config_path

    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    return config

def save_config(config: Dict[str, Any], config_path: str):
    """Save configuration to YAML file"""

    config_path = Path(config_path)
    config_path.parent.mkdir(parents=True, exist_ok=True)

    with open(config_path, 'w', encoding='utf-8') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)
